$ErrorActionPreference = 'Stop'
try {
  $taskModelDir = Join-Path $PSScriptRoot 'models'
  $taskGlbs = @(Get-ChildItem -LiteralPath $taskModelDir -File | Where-Object { $_.Extension -ieq '.glb' } | Sort-Object Name)
  if ($taskGlbs.Count -ne 1) { throw 'Leave exactly one GLB file in models, then run again.' }
  $taskUsdzs = @(Get-ChildItem -LiteralPath $taskModelDir -File | Where-Object { $_.Extension -ieq '.usdz' })
  $taskUsdz = @($taskUsdzs | Where-Object { $_.BaseName -eq $taskGlbs[0].BaseName })
  if ($taskUsdz.Count -eq 0 -and $taskUsdzs.Count -eq 1) { $taskUsdz = $taskUsdzs }
  if ($taskUsdz.Count -eq 0 -and $taskUsdzs.Count -gt 1) { throw 'Multiple USDZ files: keep one or use the same base name as GLB.' }
  $taskConfig = @{ glb = 'models/' + [Uri]::EscapeDataString($taskGlbs[0].Name); usdz = $null }
  if ($taskUsdz.Count -eq 1) { $taskConfig.usdz = 'models/' + [Uri]::EscapeDataString($taskUsdz[0].Name) }
  $taskJson = ConvertTo-Json -InputObject $taskConfig
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'models.json'), $taskJson, (New-Object Text.UTF8Encoding($false)))
  Write-Host ('READY: ' + $taskGlbs[0].Name)
  Write-Host 'Upload this entire site folder to Netlify.'
} catch {
  Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
  exit 1
}
