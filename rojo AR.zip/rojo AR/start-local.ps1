$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$taskListener = $null
try {
    for ($taskPort = 8080; $taskPort -le 8090; $taskPort++) {
        try {
            $taskListener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $taskPort)
            $taskListener.Start()
            break
        } catch {
            $taskListener = $null
        }
    }
    if ($null -eq $taskListener) { throw 'Ports 8080-8090 are busy. Close another preview server and try again.' }
    $taskUrl = "http://localhost:$taskPort/"
    Write-Host "ROJO is running at $taskUrl" -ForegroundColor Green
    Write-Host 'Keep this window open. Close it to stop the server.'
    Write-Host 'This preview is accessible only on this computer.'
    Start-Process $taskUrl
    $taskMime = @{ '.html'='text/html; charset=utf-8'; '.js'='text/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8'; '.json'='application/json; charset=utf-8'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.png'='image/png'; '.webp'='image/webp'; '.svg'='image/svg+xml'; '.woff2'='font/woff2'; '.glb'='model/gltf-binary'; '.usdz'='model/vnd.usdz+zip' }
    while ($true) {
        $taskClient = $taskListener.AcceptTcpClient()
        $taskClient.ReceiveTimeout = 5000
        $taskClient.SendTimeout = 15000
        try {
            $taskStream = $taskClient.GetStream()
            $taskReader = [IO.StreamReader]::new($taskStream, [Text.Encoding]::ASCII, $false, 8192, $true)
            $taskLine = $taskReader.ReadLine()
            if (-not $taskLine) { continue }
            $taskParts = $taskLine.Split(' ')
            if ($taskParts.Length -lt 2) { continue }
            while ($taskReader.ReadLine()) { }
            $taskPath = [Uri]::UnescapeDataString(($taskParts[1].Split('?')[0])).Replace('/', [IO.Path]::DirectorySeparatorChar)
            if ($taskPath -eq '\') { $taskPath = 'index.html' }
            $taskPath = $taskPath.TrimStart([char]'\')
            $taskTarget = [IO.Path]::GetFullPath((Join-Path $taskRoot $taskPath))
            $taskStatus = '200 OK'
            $taskType = 'text/plain; charset=utf-8'
            if ($taskParts[0] -notin @('GET','HEAD')) {
                $taskStatus = '405 Method Not Allowed'; $taskBytes = [Text.Encoding]::UTF8.GetBytes('Method not allowed')
            } elseif (-not $taskTarget.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or -not [IO.File]::Exists($taskTarget)) {
                $taskStatus = '404 Not Found'; $taskBytes = [Text.Encoding]::UTF8.GetBytes('Not found')
            } else {
                $taskBytes = [IO.File]::ReadAllBytes($taskTarget)
                $taskExt = [IO.Path]::GetExtension($taskTarget).ToLowerInvariant()
                if ($taskMime.ContainsKey($taskExt)) { $taskType = $taskMime[$taskExt] } else { $taskType = 'application/octet-stream' }
            }
            $taskHeader = "HTTP/1.1 $taskStatus`r`nContent-Type: $taskType`r`nContent-Length: $($taskBytes.Length)`r`nCache-Control: no-store`r`nConnection: close`r`nX-Content-Type-Options: nosniff`r`n`r`n"
            $taskHeaderBytes = [Text.Encoding]::ASCII.GetBytes($taskHeader)
            $taskStream.Write($taskHeaderBytes, 0, $taskHeaderBytes.Length)
            if ($taskParts[0] -eq 'GET') { $taskStream.Write($taskBytes, 0, $taskBytes.Length) }
            $taskStream.Flush()
        } catch {
            Write-Host ('Request skipped: ' + $_.Exception.Message)
        } finally {
            $taskClient.Dispose()
        }
    }
} catch {
    Write-Host ('Could not start ROJO: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($null -ne $taskListener) { $taskListener.Stop() }
}
